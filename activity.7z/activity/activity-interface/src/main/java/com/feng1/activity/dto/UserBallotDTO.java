package com.feng1.activity.dto;

import lombok.Data;

import java.io.Serializable;

@Data
public class UserBallotDTO implements Serializable{
    private static final long serialVersionUID = -1197258518054226535L;
    // 签语表
    private String ballotId;//签语编号
    private String avoidOrPleasant;//宜/忌
    private String doSomething;
    private String bgImageSrc;//签语背景图片链接
    private String signsInfo;//签语内容

}
