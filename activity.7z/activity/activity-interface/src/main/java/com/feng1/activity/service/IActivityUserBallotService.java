package com.feng1.activity.service;

import com.feng1.activity.dto.UserBallotDTO;
import com.feng1.framework.common.domain.result.ModelResult;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@RequestMapping("/activity")
@FeignClient(value = "activity-service")
public interface IActivityUserBallotService {

    /**
     * 用户每日签到
     *
     * @param userId 会员编号
     * @return ModelResult<String> 签语
     */
    @RequestMapping(value = "/ballot",method = RequestMethod.POST)
    ModelResult<UserBallotDTO> ballot(@RequestParam("userId") String userId);


}
