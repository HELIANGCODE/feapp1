package com.feng1.activity.service;

import com.feng1.activity.dto.OrderCouponRecordDTO;
import com.feng1.framework.common.domain.result.ModelResult;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@FeignClient(value = "activity-service")
@RequestMapping("/activity")
public interface IActivityOrderDetailService {
	/**
	 * 
	 * @Description:根据订单
	 * @date:2018年3月6日
	 * @author:唐攀
	 * @param orderId 活动订单ID
	 * @return
	 */
	@RequestMapping(value = "/linkDatail",method = RequestMethod.GET)
	ModelResult<List<OrderCouponRecordDTO>> linkDatail(@RequestParam("orderId")String  orderId);
}
