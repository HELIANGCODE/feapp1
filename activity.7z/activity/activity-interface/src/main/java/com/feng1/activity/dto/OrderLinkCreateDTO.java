package com.feng1.activity.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class OrderLinkCreateDTO  implements Serializable{
	private static final long serialVersionUID = 1L;
	String userId;
	String cretorOpenid;
	String orderId;
	String nickName;
	String icon;
	String phoneNumber;
	Integer optimumIndex;//最佳手气红包(满10减3)顺位值:6或7
}
