package com.feng1.activity.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class UserFeedbackQueryDTO implements Serializable{

    private static final long serialVersionUID = -3050377806015643048L;

    //用户反馈分页查询条件对象
    private int pageNo;//页码
    private int pageSize;//每页显示条数
    private String shelfId;//货架id
    private String shelfCode;//货架编码
    private String nick;//微信昵称
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date startTime;//开始时间
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date endTime;//截止时间
}
