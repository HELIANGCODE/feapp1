package com.feng1.activity.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class UserFeedbackDTO implements Serializable{

    private static final long serialVersionUID = 9009751919433831052L;

    private String feedbackId;//反馈编号
    private String shelfId;//货架id
    private String shelfCode;//货架编码
    private String nick;//微信昵称
    private String userId;//会员编号
    private Date createTime;//创建时间
    private String content;//反馈内容

}
