package com.feng1.activity.dto;

import lombok.Data;

@Data
public class DistributeCouponDTO {
	/**
	 * 说明:用户ID
	 */
	private String shelfId;//可为空
	private String couponId;
	private String userid;
	private String nickname;
	
	//领取方式：1.注册方式 2.老用户获取
	private String receiveType;
	
}
