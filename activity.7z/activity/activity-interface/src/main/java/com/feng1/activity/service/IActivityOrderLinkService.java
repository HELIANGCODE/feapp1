package com.feng1.activity.service;

import com.feng1.activity.dto.OrderLinkCreateDTO;
import com.feng1.activity.dto.OrderLinkPageInitDTO;
import com.feng1.activity.dto.ReceiveOrderLinkCouponDTO;
import com.feng1.framework.common.domain.result.ModelResult;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(value = "activity-service")
@RequestMapping("/activity")
public interface IActivityOrderLinkService {
	
	/**
	 * 
	 * @Description:生成最佳手气随机数
	 * @date:2018年3月15日
	 * @author:fanmingcai
	 * @return
	 */
	@RequestMapping(value = "/createOptimumIndex",method = RequestMethod.GET)
	public ModelResult<Integer> createOptimumIndex();
	/**
	 * 
	 * @Description:创建订单分享链接
	 * @date:2018年2月28日
	 * @author:fanmingcai
	 * @param orderLinkCreateDTO
	 * @return
	 */
	@RequestMapping(value = "/createOrderLink",method = RequestMethod.POST)
	ModelResult<Boolean> createOrderLink(@RequestBody OrderLinkCreateDTO orderLinkCreateDTO);
	
	/**
	 * @Description:订单分享链接页面初始化
	 * @date:2018年2月28日
	 * @author:fanmingcai
	 * @param orderLinkCreateDTO
	 * @return
	 */
	@RequestMapping(value = "/orderLinkPageInit",method = RequestMethod.POST)
	ModelResult<OrderLinkPageInitDTO> orderLinkPageInit(@RequestBody OrderLinkCreateDTO orderLinkCreateDTO);
	
	/**
	 * @Description:领取订单分享连接优惠券
	 * @date:2018年2月28日
	 * @author:fanmingcai
	 * @param receiveOrderLinkCouponDTO
	 * @return
	 */
	@RequestMapping(value = "/receiveOrderLinkCoupon",method = RequestMethod.POST)
	ModelResult<Boolean> receiveOrderLinkCoupon(@RequestBody ReceiveOrderLinkCouponDTO receiveOrderLinkCouponDTO);
	
}
