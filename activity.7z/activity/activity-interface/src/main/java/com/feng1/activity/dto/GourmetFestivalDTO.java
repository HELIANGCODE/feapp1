package com.feng1.activity.dto;

import lombok.Data;

import java.io.Serializable;

@Data
public class GourmetFestivalDTO implements Serializable{
    private static final long serialVersionUID = -8601657562754067706L;

    //会员编号
    private String userId;


    //是否已经领取优惠券(1,是 2，否)
    private String isReceived;

}
