package com.feng1.activity.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

@Data
public class RegisterCouponRecordDTO implements Serializable {
	private static final long serialVersionUID = 3843483658930189382L;

	  //优惠券面额
	  BigDecimal couponAmount;
	  
	  //订单金额
	  BigDecimal orderAmount;
	  
	  Date validaTime;//有效期
	  
	  String couponName;
	  
	  String couponId;
}
