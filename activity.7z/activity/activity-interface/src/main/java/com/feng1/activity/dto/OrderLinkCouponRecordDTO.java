package com.feng1.activity.dto;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

@Data
public class OrderLinkCouponRecordDTO {
	
	  String recordId;//sf_activity_order_coupon_record 表id
	  String couponRecordId;// sf_coupon_record表id
	  String memberId;//用户id
	  Integer status;//领取状态:0 未领取；1已领取
	  
	  //优惠券面额
	  BigDecimal couponAmount;
	  
	  //订单金额
	  BigDecimal orderAmount;
	  
	  Date validaTime;//有效期
	  
	  String type;//优惠券类型:1表示满10减3; 2表示满10减2;3表示满8减1
	  
	  String couponName;//优惠券名称
}
