package com.feng1.activity.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import lombok.Data;

@Data
public class OrderCouponRecordDTO implements Serializable {
	private static final long serialVersionUID = 3843483658930189382L;
	/**
	 * 说明:用户昵称
	 */
	private String nickName;
	/**
	 * 说明:用户头像
	 */
	private String icon;
	/**
	 * 说明:优惠券领取时间
	 */
	private long createTimeLong;
	/**
	 * 说明:领取状态
	 */
	private Integer status;
	/**
	 * 优惠券面额
	 */
	private BigDecimal couponAmount;
	/**
	 * 优惠券类型:1表示满10减3; 2表示满10减2;3表示满8减1',
	 */
	private String couponType;
	
	private String memberId;
	
	
}
