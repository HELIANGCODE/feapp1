package com.feng1.activity.service;

import com.feng1.activity.dto.GourmetFestivalDTO;
import com.feng1.framework.common.domain.result.ModelResult;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(value = "activity-service")
@RequestMapping("/activity")
public interface IActivityGourmetFestivalService {

    /**
     *  根据会员编号获取结果文案
     * @param userId
     * @return
     */
    @RequestMapping(value = "/getTestResult",method = RequestMethod.GET)
    ModelResult<GourmetFestivalDTO> getTestResult(@RequestParam("userId") String userId);

    /**
     *  根据会员编号更新是否领取优惠券状态
     * @param userId
     * @return
     */
    @RequestMapping(value = "/updateTestResult",method = RequestMethod.PUT)
    ModelResult updateTestResult(@RequestParam("userId") String userId);
}
