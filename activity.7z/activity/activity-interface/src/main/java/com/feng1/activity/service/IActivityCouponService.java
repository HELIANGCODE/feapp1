package com.feng1.activity.service;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.feng1.activity.dto.ActivityCouponDTO;
import com.feng1.framework.common.domain.result.ModelResult;

@FeignClient(value = "activity-service")
@RequestMapping("/activity")
public interface IActivityCouponService {
	/**
	 * 
	 * @Description:根据活动的id来获取正常的活动
	 * @param activityId 活动ID
	 * @return ModelResult<ActivityCouponDTO> 成功则ModelResult.success为true,失败为false，msg有失败的信息
	 */
	@RequestMapping(value="/getActivityCounpon",method=RequestMethod.GET)
	ModelResult<ActivityCouponDTO> getActivityCounpon(@RequestParam(value="activityId",required=true)String  activityId);
	
	
	/**
	 * 
	 * @Description:根据活动的键来获取正常的活动
	 * @param activityKey 活动key,成功则ModelResult.success为true,失败为false，msg有失败的信息
	 * @return
	 */
	@RequestMapping(value="/getActivityCounponByKey",method=RequestMethod.GET)
	ModelResult<ActivityCouponDTO> getActivityCounponByKey(@RequestParam(value="activityKey",required=true)String  activityKey);

}
