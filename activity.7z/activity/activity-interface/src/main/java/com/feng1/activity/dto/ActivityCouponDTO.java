package com.feng1.activity.dto;

import lombok.Data;
@Data
public class ActivityCouponDTO {
	private String activityId;//活动ID
	private String activityName;//配置活动名称
	private String activityKey;//配置活动key
	private String couponId;//活动的红包
}
