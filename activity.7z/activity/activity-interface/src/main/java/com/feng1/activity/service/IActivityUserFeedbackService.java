package com.feng1.activity.service;

import com.feng1.activity.dto.UserFeedbackDTO;
import com.feng1.activity.dto.UserFeedbackQueryDTO;
import com.feng1.framework.common.dao.DataPage;
import com.feng1.framework.common.domain.result.ModelResult;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@FeignClient(value = "activity-service")
@RequestMapping("/activity")
public interface IActivityUserFeedbackService {

    /**
     * 生成用户反馈记录-还想吃啥
     *
     * @param userFeedbackDTO 用户反馈信息
     * @return ModelResult<Boolean>
     */
    @RequestMapping(value = "/createFeedback",method = RequestMethod.POST)
    ModelResult createFeedback(@RequestBody UserFeedbackDTO userFeedbackDTO);

    /**
     * PC端根据条件分页查询用户反馈记录
     *
     * @param userFeedbackQueryDTO 查询条件
     * @return ModelResult<DataPage<UserFeedbackDTO>>
     */
    @RequestMapping(value = "/list",method = RequestMethod.POST)
    ModelResult<DataPage<UserFeedbackDTO>> list(@RequestBody UserFeedbackQueryDTO userFeedbackQueryDTO);

    /**
     * PC端根据用户反馈编号查询单条记录
     *
     * @param feedbackId 反馈编号
     * @return ModelResult<UserFeedbackDTO>
     */
    @RequestMapping(value = "/getUserFeedbackById",method = RequestMethod.GET)
    ModelResult<UserFeedbackDTO> getUserFeedbackById(@RequestParam("feedbackId") String feedbackId);

    /**
     *  导出用户反馈
     * @param userFeedbackQueryDTO 查询条件
     * @return
     */
    @RequestMapping(value = "/exportUserFeedback",method = RequestMethod.POST)
    ModelResult<List<UserFeedbackDTO>> exportUserFeedback(@RequestBody UserFeedbackQueryDTO userFeedbackQueryDTO);
}
