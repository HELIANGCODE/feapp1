package com.feng1.activity.dto;

import java.io.Serializable;

import lombok.Data;


@Data
public class ReceiveOrderLinkCouponDTO  implements Serializable{
	private static final long serialVersionUID = 1L;
		//领取订单分享链接优惠券
		String orderId;
		String userId;
		//订单手气红包领用记录表id
		String orderCouponRecordId;
		
		//注册用优惠券id
		String registerCouponId;
}
