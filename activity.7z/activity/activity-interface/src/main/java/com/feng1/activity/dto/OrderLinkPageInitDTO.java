package com.feng1.activity.dto;

import java.io.Serializable;
import lombok.Data;

@Data
public class OrderLinkPageInitDTO  implements Serializable{
	private static final long serialVersionUID = 1L;
	//新手注册领用红包
	private RegisterCouponRecordDTO avaliableRegisterCoupon;
	
	//分享红包
	private OrderLinkCouponRecordDTO linkCouponRecordDTO;
	
	//用户领过的新手红包
	private OrderLinkCouponRecordDTO ownerRegisterCoupon;
	
	String code;
	String msg;
	String phoneNumber;
	//最佳手气顺位
	Integer optimumIndex;
}
