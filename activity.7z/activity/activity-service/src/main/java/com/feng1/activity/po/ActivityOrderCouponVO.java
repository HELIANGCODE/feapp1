package com.feng1.activity.po;

import java.io.Serializable;
import java.math.BigDecimal;

import com.mysql.jdbc.interceptors.ServerStatusDiffInterceptor;

import lombok.Data;

@Data
public class ActivityOrderCouponVO implements Serializable{
	private static final long serialVersionUID = 1L;
	//订单分享活动优惠券信息表
	  private Integer couponType;//优惠券类型:1表示满10减3; 2表示满10减2;3表示满8减1
	  
	  private String couponId;//优惠券id
	  //优惠券面额
	  private BigDecimal couponAmount;
	  
	  //订单金额
	  private BigDecimal orderAmount;
	  
	  //红包名称
	  String couponName;
}
