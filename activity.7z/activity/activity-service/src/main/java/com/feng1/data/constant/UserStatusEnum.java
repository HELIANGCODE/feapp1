package com.feng1.data.constant;

public enum UserStatusEnum {
	
	Normal("正常用户", "0"),
    Low("低频用户", "1"),
    Corpse("僵尸用户", "2"),
    Loss("流失用户", "3");
	
    private String code;
    
    private String name;
    
    /**
     * 构造函数
     * 
     * @param name name
     * @param index index
     */
    private UserStatusEnum(String name, String code) {
        this.name = name;
        this.code = code;
    }

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
    

}
