package com.feng1.activity.po;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

@Data
public class OrderCouponRecordPO implements Serializable {
	private static final long serialVersionUID = 3843483658930189382L;
	/**
	 * 说明:用户昵称
	 */
	private String nickName;
	/**
	 * 说明:用户头像
	 */
	private String icon;
	/**
	 * 说明:优惠券领取时间
	 */
	private Date createTime;
	/**
	 * 说明:领取状态
	 */
	private Integer status;
	/**
	 * 优惠券面额
	 */
	private BigDecimal couponAmount;
	/**
	 * 优惠券类型:1表示满10减3; 2表示满10减2;3表示满8减1',
	 */
	private String couponType;
	
	private String memberId;
	
}