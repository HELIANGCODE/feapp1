package com.feng1.activity.po.feng1;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import lombok.Data;

@Data
public class CouponRecordPO   implements Serializable{
	  /**
	 * 
	 */
	  private static final long serialVersionUID = 1L;

	  String recordId;//编号',
	  String couponId;//优惠券编号',
	  String childId;//子优惠券编号',
	  String couponSn;//SN标识',
	  String couponPwd;//校验码',
	  String shelfId;//货架编号',
	  Date couponTime;//领取时间',
	  String userId;//领取人编号',
	  String userName;//领取人名称',
	  Date userdTime;//使用时间',
	  String orderId;//订单编号',
	  String couponStatus;//优惠券状态(1:待领取、2:已领取、3:已使用、4:已过期)(DICT)',
	  Date validTime;//截止时间',
	  String couponChannel;//领取渠道(1:线上、2:线下;3:分享红包)(DICT)',
	  
	  String couponName;
	  BigDecimal price;//价格
	  BigDecimal orderAmount;//
	  
	  String childCouponName;
	  BigDecimal childPrice;
	  BigDecimal childOrderAmount;
	  String couponModel;//1:优惠券、2:优惠券包
	  String receiveType;//领取方式(1:注册领取;2 老用户)
}
