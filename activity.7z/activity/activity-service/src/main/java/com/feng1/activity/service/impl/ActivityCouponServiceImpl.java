package com.feng1.activity.service.impl;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.RestController;

import com.feng1.activity.constant.CacheConstant;
import com.feng1.activity.dto.ActivityCouponDTO;
import com.feng1.activity.po.ActivityCouponPO;
import com.feng1.activity.service.IActivityCouponService;
import com.feng1.framework.common.dao.GenericDao;
import com.feng1.framework.common.domain.result.ModelResult;
import com.feng1.framework.common.redis.RedisClient;
import com.feng1.framework.util.JsonUtils;

@RestController
public class ActivityCouponServiceImpl implements IActivityCouponService {
    @Autowired
    @Qualifier("activityReadDao")
    private GenericDao activityReadDao;

    @Autowired
    private RedisClient redisclient;

    private static Logger LOGGER = LoggerFactory.getLogger(ActivityCouponServiceImpl.class);

    @Override
    public ModelResult<ActivityCouponDTO> getActivityCounpon(String activityId) {
        ActivityCouponPO activityCouponPO = getByActivityId(activityId);
        return getByResult(activityCouponPO);
    }

    @Override
    public ModelResult<ActivityCouponDTO> getActivityCounponByKey(String activityKey) {
        ActivityCouponPO activityCouponPO = getByKey(activityKey);
        return getByResult(activityCouponPO);
    }

    private ActivityCouponPO getByKey(String activityKey) {
        ActivityCouponPO activityCouponPO = null;
        String cacheKey = CacheConstant.ACTIVITY_COUPON_CACHE_KEY + activityKey;
        String cacheStr = getCacheByKey(cacheKey);
        if (cacheStr == null) {
            activityCouponPO = activityReadDao.queryOne("ActivityCouponPOMapper.selectByActivityKey", activityKey);
            saveCache(activityCouponPO, cacheKey);
        } else {
            activityCouponPO = JsonUtils.jsonToBean(cacheStr, ActivityCouponPO.class);
        }
        return activityCouponPO;
    }

    private ActivityCouponPO getByActivityId(String activityId) {
        ActivityCouponPO activityCouponPO = null;
        String cacheKey = CacheConstant.ACTIVITY_COUPON_CACHE_ID + activityId;
        String cacheStr = getCacheByKey(cacheKey);
        if (cacheStr == null) {
            activityCouponPO = activityReadDao.queryOne("ActivityCouponPOMapper.selectByActivityId", Long.valueOf(activityId));
            saveCache(activityCouponPO, cacheKey);
        } else {
            activityCouponPO = JsonUtils.jsonToBean(cacheStr, ActivityCouponPO.class);
        }
        return activityCouponPO;
    }

    private String getCacheByKey(String cacheKey) {
        try {
            String cacheStr = redisclient.get(cacheKey);
            return cacheStr;
        } catch (Exception e) {
            LOGGER.error("根据活动key：{},从缓存中获取活动红包出错，忽略异常，从数据库中获取", cacheKey, e);
        }
        return null;
    }

    private void saveCache(ActivityCouponPO activityCouponPO, String cacheKey) {
        try {
            redisclient.set(cacheKey, activityCouponPO, activityCouponPO == null ? 5 * 60 : 60 * 60);// 为空则保存5分钟，否则保存1个小时
        } catch (Exception e) {
            LOGGER.error("保存活动到缓存失败key：{},值：{}", cacheKey, JsonUtils.beanToJson(activityCouponPO), e);
        }
    }

    private ModelResult<ActivityCouponDTO> getByResult(ActivityCouponPO activityCouponPO) {
        ModelResult<ActivityCouponDTO> modelResult = new ModelResult<ActivityCouponDTO>();
        if (activityCouponPO == null) {
            modelResult.setSuccess(false);
            modelResult.setMsg("活动不存在或已过期");
            return modelResult;
        }
        modelResult.setSuccess(true);
        modelResult.setData(convertToDTO(activityCouponPO));
        return modelResult;
    }

    private ActivityCouponDTO convertToDTO(ActivityCouponPO activityCouponPO) {
        ActivityCouponDTO activityCouponDTO = new ActivityCouponDTO();
        activityCouponDTO.setActivityId(activityCouponPO.getActivityId().toString());
        activityCouponDTO.setActivityName(activityCouponPO.getActivityName());
        if (activityCouponPO.getCouponId() != null) {
            activityCouponDTO.setCouponId(activityCouponPO.getCouponId().toString());
        }
        activityCouponDTO.setActivityKey(activityCouponPO.getActivityKey());
        return activityCouponDTO;
    }
}
