package com.feng1.activity.po;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;

@Data
public class ActivityOrderLinkPO implements Serializable{
	private static final long serialVersionUID = 1L;
	//订单手气红包链接记录
	  String linkId;//记录主键',
	  Integer manShiJianEr;//是否产生满10减2红包:1产生 ;0不产生
	  String orderId;//订单id',
	  Date createTime;//分享链接生成时间',
	  String creatorId;//分享发起人id',
	  String cretorOpenid;//分享发起人openid',
	  Integer optimumIndex;//最佳手气红包(满10减3)顺位值:6或7
}
