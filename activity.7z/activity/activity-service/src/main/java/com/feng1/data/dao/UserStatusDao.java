package com.feng1.data.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.feng1.data.po.UserStatus;
import com.feng1.framework.common.dao.GenericDao;


@Repository
public class UserStatusDao {
	@Autowired
	@Qualifier("dataReadDao")
    private GenericDao dataReadDao;
	public UserStatus getUserStatusByUserId(String userId){
		return (UserStatus) dataReadDao.queryObject("UserStatusMapper.selectByPrimaryKey", userId);
	}
}
