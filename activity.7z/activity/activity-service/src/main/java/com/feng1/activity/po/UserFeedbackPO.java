package com.feng1.activity.po;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class UserFeedbackPO implements Serializable{

    private static final long serialVersionUID = -5298042912282060075L;
    //用户反馈记录-还想吃啥
    private String feedbackId;//反馈编号
    private String shelfId;//货架编号
    private String shelfCode;//货架编码
    private String nick;//微信昵称
    private String userId;//会员编号
    private Date createTime;//创建时间
    private String content;//反馈内容
    private String dataFlag;//数据状态(1:正常、2:删除)
}
