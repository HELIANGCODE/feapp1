package com.feng1.activity.service.impl;

import com.feng1.activity.dto.UserFeedbackDTO;
import com.feng1.activity.dto.UserFeedbackQueryDTO;
import com.feng1.activity.po.UserFeedbackPO;
import com.feng1.activity.service.IActivityUserFeedbackService;
import com.feng1.framework.common.dao.DataPage;
import com.feng1.framework.common.dao.GenericDao;
import com.feng1.framework.common.domain.result.ModelResult;
import com.feng1.framework.common.domain.result.ModelResultClient;
import com.feng1.framework.common.util.IDGeneratorUtil;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@RestController
public class ActivityUserFeedbackServiceImpl implements IActivityUserFeedbackService {
    private static final Logger LOGGER = LoggerFactory.getLogger(ActivityUserFeedbackServiceImpl.class);

    @Autowired
    @Qualifier("activityReadDao")
    private GenericDao activityReadDao;

    @Autowired
    @Qualifier("activityWriteDao")
    private GenericDao activityWriteDao;

    @Override
    public ModelResult createFeedback(@RequestBody UserFeedbackDTO userFeedbackDTO) {
        if (StringUtils.isBlank(userFeedbackDTO.getUserId())) {
            return new ModelResultClient().failFactory("6101","会员编号不能为空");
        }
        if (StringUtils.isBlank(userFeedbackDTO.getNick())) {
            return new ModelResultClient().failFactory("6102","微信昵称不能为空");
        }
        if (StringUtils.isBlank(userFeedbackDTO.getContent())) {
            return new ModelResultClient().failFactory("6103","反馈内容不能为空");
        }
        UserFeedbackPO userFeedbackPO = new UserFeedbackPO();
        try {
            BeanUtils.copyProperties(userFeedbackPO,userFeedbackDTO);
        } catch (Exception e) {
            LOGGER.error(e.getLocalizedMessage(),e);
            return new ModelResultClient().failFactory();
        }
        userFeedbackPO.setFeedbackId(IDGeneratorUtil.nextId());
        userFeedbackPO.setCreateTime(new Date());
        activityWriteDao.insertAndSetupId("ActivityUserFeedbackMapper.insert", userFeedbackPO);
        LOGGER.info("用户{}提交了反馈内容{}",userFeedbackDTO.getUserId(),userFeedbackPO);
        return new ModelResultClient().successFactory();
    }

    @Override
    public ModelResult<DataPage<UserFeedbackDTO>> list(@RequestBody UserFeedbackQueryDTO userFeedbackQueryDTO) {
        int pageNo = userFeedbackQueryDTO.getPageNo();
        int pageSize = userFeedbackQueryDTO.getPageSize();
        if (pageNo == 0) {
            pageNo=1;
        }
        if (pageSize == 0) {
            pageSize=30;
        }
        DataPage<UserFeedbackDTO> page = new DataPage<>(pageNo, pageSize);
        Map<String, Object> map = new HashMap<>();
        map.put("startIndex", page.getFirst());
        map.put("pageSize", page.getPageSize());
        map.put("param", userFeedbackQueryDTO);
        page = activityReadDao.queryPage("ActivityUserFeedbackMapper.getCountByParms", "ActivityUserFeedbackMapper.list", map, page);
        LOGGER.debug("查询条件:{},分页查询用户反馈数据:{}",userFeedbackQueryDTO,page);
        return new ModelResultClient<DataPage<UserFeedbackDTO>>().successFactory(page);
    }

    @Override
    public ModelResult<UserFeedbackDTO> getUserFeedbackById(String feedbackId) {
        if (StringUtils.isBlank(feedbackId)) {
            return new ModelResultClient<UserFeedbackDTO>().failFactory("6104","反馈编号feedbackId不能为空");
        }
        UserFeedbackDTO userFeedbackDTO = activityReadDao.queryUniqueById("ActivityUserFeedbackMapper.getUserFeedbackById",feedbackId);
        LOGGER.debug("根据反馈编号{},查询反馈详情{}",feedbackId,userFeedbackDTO);
        return new ModelResultClient<UserFeedbackDTO>().successFactory(userFeedbackDTO);
    }

    @Override
    public ModelResult<List<UserFeedbackDTO>> exportUserFeedback(@RequestBody UserFeedbackQueryDTO userFeedbackQueryDTO) {
        LOGGER.info("开始导出用户反馈数据!");
        Map<String, Object> map = new HashMap<>();
        map.put("param", userFeedbackQueryDTO);
        int record = activityReadDao.queryCount("ActivityUserFeedbackMapper.getCountByParms", map);
        int pageSize = userFeedbackQueryDTO.getPageSize();
        if (record > pageSize) {
            return new ModelResultClient<List<UserFeedbackDTO>>().failFactory("-1","查询到的记录数超过"+pageSize+"条,无法导出!");
        }
        List<UserFeedbackDTO> result = new ArrayList<>();
        if (record>0){
            result = activityReadDao.queryList("ActivityUserFeedbackMapper.export", map);
            LOGGER.info("已导出用户反馈记录"+record+"条!");
        }
        return new ModelResultClient<List<UserFeedbackDTO>>().successFactory(result);
    }
}
