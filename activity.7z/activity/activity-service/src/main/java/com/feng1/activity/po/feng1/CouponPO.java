package com.feng1.activity.po.feng1;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

@Data
public class CouponPO  implements Serializable {
	private static final long serialVersionUID = 1L;

    /** 编号 **/
    private Long couponId;
    
    /** 优惠券名称 **/
    private String couponName;
    
    /** 优惠券类型 电子券，纸质券 **/
    private Integer couponType;
    
    /**
     * 券包类型(1:优惠券、2:优惠券包）
     */
    private String couponModel;
    
    /** 价格 **/
    private BigDecimal price;
    
    /** 订单金额（满足多少钱才能使用） **/
    private BigDecimal orderAmount;
    
    /** 发行张数 **/
    private Integer num;
    
    /** 可领取张数 **/
    private Integer perMax;
    
    /** 领用开始时间 **/
    private Date startTime;
    
    /** 领用结束时间 **/
    private Date endTime;
    
    /** 截止时间 **/
    private Date validTime;
    
    /** 领取方式 1:注册领取**/
    private Integer receiveType;
    
    /** 是否需要校验码 **/
    private Integer whetherSn;
    
    /** 添加时间 **/
    private Date addTime;
    
    /** 添加人编号 **/
    private Long addUserId;
    
    /** 最后修改人编号 **/
    private Long lastUpdateUserId;
    
    /** 最后修改时间 **/
    private Date lastUpdateTime;
    
    /** 数据状态(1:正常、2:删除) **/
    private Integer dataFlag;
    
    /** 是否有效天数 **/
    private Integer whetherDay;
    
    /** 有效天数 **/
    private Integer validDay;

}
