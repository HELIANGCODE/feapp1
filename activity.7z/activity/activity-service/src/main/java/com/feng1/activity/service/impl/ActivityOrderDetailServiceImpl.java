package com.feng1.activity.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.RestController;

import com.feng1.activity.dto.OrderCouponRecordDTO;
import com.feng1.activity.po.ActivityOrderLinkPO;
import com.feng1.activity.po.OrderCouponRecordPO;
import com.feng1.activity.service.IActivityOrderDetailService;
import com.feng1.framework.common.dao.GenericDao;
import com.feng1.framework.common.domain.result.ModelResult;
import com.feng1.framework.common.domain.result.ModelResultClient;
import com.google.common.collect.Maps;

@RestController
public class ActivityOrderDetailServiceImpl implements IActivityOrderDetailService{
	@Autowired
	@Qualifier("activityReadDao")
    private GenericDao activityReadDao;
	@Override
	public ModelResult<List<OrderCouponRecordDTO>> linkDatail(String orderId) {
		ActivityOrderLinkPO orderLink = getOrderLink(orderId);
		List<OrderCouponRecordDTO> resultList = null;
		List<OrderCouponRecordPO> list = activityReadDao.queryList("OrderCouponRecordMapper.selectList", orderLink.getLinkId());
		if(list.size()>0){
			resultList = new ArrayList<OrderCouponRecordDTO>();
			for(OrderCouponRecordPO po : list){
				OrderCouponRecordDTO dto = new OrderCouponRecordDTO();
				BeanUtils.copyProperties(po, dto);
				dto.setCreateTimeLong(po.getCreateTime().getTime());
				//用户昵称进行星号处理
				if(StringUtils.isNoneBlank(po.getNickName())){
					StringBuffer nickName = new StringBuffer();
					for (int i = 0; i < po.getNickName().length(); i++) {
			            if(i == 0){
			            	nickName.append(po.getNickName().charAt(i)); 
			            }else{
			            	nickName.append("*");
			            }
			        }
					dto.setNickName(nickName.toString());
				}
				resultList.add(dto);
			}
		}
		return new ModelResultClient<List<OrderCouponRecordDTO>>().successFactory(resultList);
	}
	
	//查询订单链接
	private ActivityOrderLinkPO getOrderLink(String orderId){
		HashMap<String, Object> params0 = Maps.newHashMap();
		params0.put("orderId", orderId);                  
		ActivityOrderLinkPO orderLink = activityReadDao.queryOne("ActivityOrderLinkMapper.getOne", params0);
		return orderLink;
	}
}
