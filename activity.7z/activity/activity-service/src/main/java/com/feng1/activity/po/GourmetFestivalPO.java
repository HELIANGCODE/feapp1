package com.feng1.activity.po;

import lombok.Data;

import java.io.Serializable;

@Data
public class GourmetFestivalPO implements Serializable{
    private static final long serialVersionUID = 1554637189576038764L;

    //主键
    private String id;

    //会员编号
    private String userId;


    //是否已经领取优惠券(1,是 2，否)
    private String isReceived;

}
