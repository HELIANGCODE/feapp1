package com.feng1.activity.service.impl;

import com.feng1.activity.dto.UserBallotDTO;
import com.feng1.activity.po.UserBallotRecordPO;
import com.feng1.activity.service.IActivityUserBallotService;
import com.feng1.framework.common.dao.GenericDao;
import com.feng1.framework.common.domain.result.ModelResult;
import com.feng1.framework.common.domain.result.ModelResultClient;
import com.feng1.framework.common.util.IDGeneratorUtil;
import com.feng1.framework.util.DateUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;

@RestController
public class ActivityUserBallotServiceImpl implements IActivityUserBallotService {

    private static final Logger LOGGER = LoggerFactory.getLogger(ActivityUserBallotServiceImpl.class);

    @Autowired
    @Qualifier("activityReadDao")
    private GenericDao activityReadDao;

    @Autowired
    @Qualifier("activityWriteDao")
    private GenericDao activityWriteDao;


    @Override
    public ModelResult<UserBallotDTO> ballot(String userId) {
        if (StringUtils.isBlank(userId)) {
            return new ModelResultClient<UserBallotDTO>().failFactory("6101", "会员编号不能为空");
        }
        String date = DateUtil.formatDate(new Date());
        Map<String, Object> map = new HashMap<>();
        map.put("userId", userId);
        map.put("date", date);
        // 根据会员编号和日期查询签到记录表
        UserBallotRecordPO userBallotRecordPO = activityReadDao.queryOne("ActivityUserBallotRecordMapper.getBallotRecordByUserIdAndDate", map);
        UserBallotDTO userBallotDTO = null;
        String content = "";
        if (userBallotRecordPO != null) {
            // 当天已经签到,返回当天签到的签语
            userBallotDTO = activityReadDao.queryOne("ActivityUserBallotMapper.getBallotByPrimaryKey", userBallotRecordPO.getBallotId());
        } else {
            // 当天未签到,返回新的签语
            userBallotDTO = getNewBallot(map);
            if (userBallotDTO != null) {
                userBallotRecordPO = new UserBallotRecordPO();
                userBallotRecordPO.setBallotId(userBallotDTO.getBallotId());
                userBallotRecordPO.setCreateTime(new Date());
                userBallotRecordPO.setRecordId(IDGeneratorUtil.nextId());
                userBallotRecordPO.setUserId(userId);
                activityWriteDao.insertAndReturnAffectedCount("ActivityUserBallotRecordMapper.insert",userBallotRecordPO);
                LOGGER.info("用户{}今日签到!",userId);
            }
        }
        LOGGER.debug("用户{},今日签语:{}",userId,userBallotDTO);
        return new ModelResultClient<UserBallotDTO>().successFactory(userBallotDTO);
    }


    private UserBallotDTO getNewBallot(Map<String, Object> map) {
        // 查询签语表
        List<UserBallotDTO> ballotList = activityReadDao.queryList("ActivityUserBallotMapper.listAllBallot", null);
        if (ballotList == null || ballotList.size() < 1) {
            LOGGER.info("数据库中没有签语模板!");
            return null;
        }
        //获取该用户所有抽过的签语记录(去重)
        List<String> recordList = activityReadDao.queryList("ActivityUserBallotRecordMapper.getAllBallotRecordByUserId", map.get("userId"));
        Random random = new Random();
        if (recordList == null || recordList.size() < 1 || recordList.size() >= ballotList.size()) {
            // 第一次签到或者已经轮完一轮
            return ballotList.get(random.nextInt(ballotList.size()));
        }

        Iterator<UserBallotDTO> iterator = ballotList.iterator();
        while (iterator.hasNext()) {
            UserBallotDTO userBallotDTO = iterator.next();
            for (String record : recordList) {
                String ballotId = userBallotDTO.getBallotId();
                if (ballotId.equals(record)) {
                    // 已经抽过的签语
                    iterator.remove();
                }
            }
        }
        return ballotList.get(random.nextInt(ballotList.size()));
    }
}
