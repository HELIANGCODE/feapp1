package com.feng1.activity.po;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class UserBallotRecordPO implements Serializable{

    private static final long serialVersionUID = 4095951124412313154L;

    // 用户每日签到表
    private String recordId;//记录表主键
    private String ballotId;//签语编号
    private String userId;//会员编号
    private Date createTime;//签到日期(年月日)
    private String dataFlag;//数据状态(1:正常、2:删除)

}
