package com.feng1.activity.util;

import java.util.Random;

public class ProbabilityCalculationUtil {
	
	/**
	 * 
	 * @Description:概率命中计算
	 * @date:2018年3月6日
	 * @author:fanmingcai
	 * @param probabilityValue:概率值，按百分比算
	 * @return
	 */
	public static boolean calculation(Integer probabilityValue){
		Random r = new Random();
		// 生成一个介于0(包含)到n(不包含)之间的整数
		int nextInt = r.nextInt(101);// [0-100}

		if (nextInt <= probabilityValue.intValue()) {
			return true;
		} else{
			return false;
		}
	}
}
