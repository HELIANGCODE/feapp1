package com.feng1.activity.constant;

public interface CacheConstant {
	String ACTIVITY_COUPON_CACHE_KEY="ACTIVITY_COUPON_CACHE_KEY:";
	String ACTIVITY_COUPON_CACHE_ID="ACTIVITY_COUPON_CACHE_ID:";
}
