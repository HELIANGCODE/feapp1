package com.feng1.activity.service.impl;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.feng1.activity.dto.DistributeCouponDTO;
import com.feng1.activity.dto.OrderLinkCouponRecordDTO;
import com.feng1.activity.dto.OrderLinkCreateDTO;
import com.feng1.activity.dto.OrderLinkPageInitDTO;
import com.feng1.activity.dto.ReceiveOrderLinkCouponDTO;
import com.feng1.activity.po.ActivityOrderCouponRecordPO;
import com.feng1.activity.po.ActivityOrderCouponVO;
import com.feng1.activity.po.ActivityOrderLinkPO;
import com.feng1.activity.po.feng1.CouponPO;
import com.feng1.activity.po.feng1.CouponRecordPO;
import com.feng1.activity.service.IActivityOrderLinkService;
import com.feng1.activity.util.ProbabilityCalculationUtil;
import com.feng1.data.po.UserStatus;
import com.feng1.framework.common.dao.GenericDao;
import com.feng1.framework.common.domain.result.ModelResult;
import com.feng1.framework.common.domain.result.ModelResultClient;
import com.feng1.framework.common.util.IDGeneratorUtil;
import com.feng1.framework.util.DateUtil;
import com.feng1.framework.util.JsonUtils;
import com.google.common.collect.Maps;

@RestController
@RequestMapping("/activity")
public class ActivityOrderLinkServiceImpl implements IActivityOrderLinkService {
	private static final Logger LOGGER = LoggerFactory.getLogger(ActivityOrderLinkServiceImpl.class);
	
	@Autowired
	@Qualifier("activityReadDao")
    private GenericDao activityReadDao;
	
	@Autowired
	@Qualifier("activityWriteDao")
    private GenericDao activityWriteDao;
	
	@Autowired
	@Qualifier("feng1ReadDao")
    private GenericDao feng1ReadDao;
	
	@Autowired
	@Qualifier("feng1WriteDao")
    private GenericDao feng1WriteDao;	
	
	@Autowired
	@Qualifier("dataReadDao")
    private GenericDao dataReadDao;
	
	@Override
	public ModelResult<Integer> createOptimumIndex() {
		boolean calculation = ProbabilityCalculationUtil.calculation(70);
		return new ModelResultClient<Integer>().successFactory(calculation?6:7);
	}
	@Override
	public ModelResult<Boolean> createOrderLink(@RequestBody OrderLinkCreateDTO linkCreateDTO) {
		HashMap<String, String> param0= Maps.newHashMap();
		String orderId = linkCreateDTO.getOrderId();
		param0.put("orderId", orderId);
		String dataOrder = feng1ReadDao.queryOne("CouponMapper.getOneOrder", param0);
		if(StringUtils.isEmpty(dataOrder)){
			return new ModelResultClient<Boolean>().failFactory("5000", "非法订单，不能创建分享");
		}
		
		HashMap<String, Object> params = Maps.newHashMap();
		params.put("orderId", orderId);  
		Object queryOne = activityReadDao.queryOne("ActivityOrderLinkMapper.getOne", params);
		if(queryOne!=null){
			return new ModelResultClient<Boolean>().failFactory("5003", "同一个订单只能生成一次连接");
		}
		int queryInt = activityReadDao.queryInt("ActivityOrderLinkMapper.countIndex", null);
		
		ActivityOrderLinkPO orderLinkPO = new ActivityOrderLinkPO();
		orderLinkPO.setLinkId(IDGeneratorUtil.nextId());
		orderLinkPO.setOrderId(orderId);
		orderLinkPO.setCreateTime(new Date());
		//是否产生满10减2红包
		if((queryInt+1)%10==0){
			orderLinkPO.setManShiJianEr(1);
		}else{
			orderLinkPO.setManShiJianEr(0);
		}
		//计算最佳手气顺位（第6或者第7位）
//		boolean calculation = ProbabilityCalculationUtil.calculation(70);
		orderLinkPO.setOptimumIndex(linkCreateDTO.getOptimumIndex());
		orderLinkPO.setCreatorId(linkCreateDTO.getUserId());
		orderLinkPO.setCretorOpenid(linkCreateDTO.getCretorOpenid());
		activityReadDao.insertAndReturnAffectedCount("ActivityOrderLinkMapper.insert", orderLinkPO);
		OrderLinkCreateDTO orderLinkCreateDTO = new OrderLinkCreateDTO();
		orderLinkCreateDTO.setOptimumIndex(orderLinkPO.getOptimumIndex());
		return new ModelResultClient<Boolean>().successFactory(true);
	}

	@Override
	public ModelResult<OrderLinkPageInitDTO> orderLinkPageInit(@RequestBody OrderLinkCreateDTO linkCreateDTO) {
		LOGGER.info("红包分享页面数据初始化,linkCreateDTO:{}",JsonUtils.beanToJson(linkCreateDTO));
		String userId = linkCreateDTO.getUserId();
		String orderId = linkCreateDTO.getOrderId();
		String phoneNumber = linkCreateDTO.getPhoneNumber();
		OrderLinkPageInitDTO returnDate = new OrderLinkPageInitDTO();
		returnDate.setPhoneNumber(phoneNumber);
		ModelResult methodReturn = new ModelResult();
		
		HashMap<String, String> param0= Maps.newHashMap();
		param0.put("orderId", orderId);
		String dataOrder = feng1ReadDao.queryOne("CouponMapper.getOneOrder", param0);
		if(StringUtils.isEmpty(dataOrder)){
			return new ModelResultClient<OrderLinkPageInitDTO>().failFactory("5000", "非法订单数据，不能获取分享信息");
		}
		ActivityOrderLinkPO orderLinkPO = getOrderLink(orderId,linkCreateDTO.getUserId(),linkCreateDTO.getCretorOpenid());
		returnDate.setOptimumIndex(orderLinkPO.getOptimumIndex());
		String linkId = orderLinkPO.getLinkId();
		HashMap<String, Object> params2 = Maps.newHashMap();
		params2.put("linkId", linkId);
		params2.put("userId", userId);
		params2.put("couponType", "1");
		List<ActivityOrderCouponRecordPO> queryList2 = activityReadDao.queryList("ActivityOrderCouponRecord.selectList", params2);
		if(CollectionUtils.isNotEmpty(queryList2)){
			if(queryList2!=null&&queryList2.size()>=1){
				ActivityOrderCouponRecordPO po = queryList2.get(0);
				//1.1同一个用户，一个分享连接最多只能领取一张优惠券，重复打开已经领取过的连接，提示:这是一个已抢过的红包哦~
				if (po.getStatus().intValue() == 1){
					returnDate.setCode("5003");
					returnDate.setMsg("你已经抢过这个红包了~");
				}
				//1.2 用户已经领取过优惠券，则直接从数据库查询
				String couponId = po.getCouponId();
				ActivityOrderCouponVO orderCoupon = getOrderCoupon(null,couponId);
				OrderLinkCouponRecordDTO linkCouponRecordDTO = new OrderLinkCouponRecordDTO();
				linkCouponRecordDTO.setRecordId(po.getRecordId());
				linkCouponRecordDTO.setStatus(po.getStatus());
				linkCouponRecordDTO.setCouponAmount(orderCoupon.getCouponAmount());
				linkCouponRecordDTO.setOrderAmount(orderCoupon.getOrderAmount());
				linkCouponRecordDTO.setValidaTime(po.getValidatTime());
				linkCouponRecordDTO.setCouponName(orderCoupon.getCouponName());
				returnDate.setLinkCouponRecordDTO(linkCouponRecordDTO);
				
				
				//1.3.返回用户已有的注册的优惠券
				HashMap<String, Object> ownerRegisterCouponParam = Maps.newHashMap();
				ownerRegisterCouponParam.put("linkId", linkId);
				ownerRegisterCouponParam.put("couponType", "2");
				ownerRegisterCouponParam.put("userId", userId);
				List<ActivityOrderCouponRecordPO> lists4 = activityReadDao.queryList("ActivityOrderCouponRecord.selectList", ownerRegisterCouponParam);
				if(CollectionUtils.isNotEmpty(lists4)&&lists4.size()>0){
					ActivityOrderCouponRecordPO ownerRegisterCoupon = lists4.get(0);
					
					String registCouponId = ownerRegisterCoupon.getCouponId();
					OrderLinkCouponRecordDTO registerCouponRecord = new OrderLinkCouponRecordDTO();
					registerCouponRecord.setRecordId(ownerRegisterCoupon.getRecordId());
					registerCouponRecord.setStatus(ownerRegisterCoupon.getStatus());
					CouponPO registerCoupon = getCoupon(registCouponId);
					registerCouponRecord.setCouponAmount(registerCoupon.getPrice());
					registerCouponRecord.setOrderAmount(registerCoupon.getOrderAmount());
					registerCouponRecord.setValidaTime(ownerRegisterCoupon.getValidatTime());
					registerCouponRecord.setCouponName(registerCoupon.getCouponName());
					returnDate.setOwnerRegisterCoupon(registerCouponRecord);
				}
				methodReturn.setData(returnDate);
			}
		}else{
			//2.1 同一个用户，一天最多只能领取三张优惠券，今天的3次抢红包机会已经用完哦~
			{
				HashMap<String, Object> params1 = Maps.newHashMap();
				String today = DateUtil.formatDate(new Date(), "yyyy-MM-dd");
				params1.put("dateBegin", today+" 00:00:01");
				params1.put("dateEnd", today+" 23:59:59");
				params1.put("userId", userId);
				params1.put("couponType", "1");
				List<ActivityOrderCouponRecordPO> queryList = activityReadDao.queryList("ActivityOrderCouponRecord.selectList", params1);
				if(queryList!=null&&queryList.size() >=3 ){
					returnDate.setCode("5004");
					returnDate.setMsg("今天的红包机会用完了");
					ModelResult<OrderLinkPageInitDTO> data2 = new ModelResultClient<OrderLinkPageInitDTO>().successFactory(returnDate);
					LOGGER.info("接口返回数据:{}",JsonUtils.beanToJson(data2));
					return data2;
				}
			}
			
			Map<String, Object> param = new HashMap<String, Object>();
			int queryCount = activityReadDao.queryCount("ActivityOrderCouponMapper.count", param);
			if(queryCount==0){
				returnDate.setCode("5005");
				returnDate.setMsg("这个红包已被抢完");
				ModelResult<OrderLinkPageInitDTO> data2 = new ModelResultClient<OrderLinkPageInitDTO>().successFactory(returnDate);
				LOGGER.info("接口返回数据:{}",JsonUtils.beanToJson(data2));
				return data2;
			}
			
			//2.2 同一个连接，最多只产生15张优惠券，15张领完后，仍然有用户打开连接，提示：这个红包已被抢完。
			List<ActivityOrderCouponRecordPO> queryList3;
			{
				HashMap<String, Object> params3 = Maps.newHashMap();
				params3.put("linkId", linkId);
				params3.put("couponType", "1");
				queryList3 = activityReadDao.queryList("ActivityOrderCouponRecord.selectList", params3);
				if(queryList3 != null && queryList3.size() >=15){
					returnDate.setCode("5005");
					returnDate.setMsg("这个红包已被抢完。");
					ModelResult<OrderLinkPageInitDTO> data3 = new ModelResultClient<OrderLinkPageInitDTO>().successFactory(returnDate);
					LOGGER.info("接口返回数据:{}",JsonUtils.beanToJson(data3));
					return data3;
				}
			}
			
			
			//2.3 给用户分优惠券
			Integer receiveIndex;
			if (queryList3 == null || queryList3.size() == 0) {
				receiveIndex=1;
			} else {
				receiveIndex = queryList3.size()+1;
			}
			Integer optimumIndex = orderLinkPO.getOptimumIndex();
			boolean manShiJianEr = false;//是否分配了满10减二红包
			boolean optimum = false;//是否分配了最佳手气红包
			ActivityOrderCouponRecordPO orderCouponRecord = null;
			String couponName = null;
			  //优惠券面额
			BigDecimal couponAmount = null;
			  //订单金额
			BigDecimal orderAmount = null;
			
			if(optimumIndex.intValue()==receiveIndex.intValue()){
				//2.3.1只能有一个最佳手气红包
				optimum = true;
				//产生最佳手气红包
				ActivityOrderCouponVO optimumOrderCoupon = getOrderCoupon("1",null);
				ActivityOrderCouponRecordPO dto = new ActivityOrderCouponRecordPO();
				dto.setMemberId(userId);
				dto.setCouponId(optimumOrderCoupon.getCouponId());
				dto.setLinkId(linkId);
				dto.setNickName(linkCreateDTO.getNickName());
				dto.setRecordIndex(receiveIndex);
				dto.setIcon(linkCreateDTO.getIcon());
				dto.setOpenid(linkCreateDTO.getCretorOpenid());
				dto.setPhoneNumber(phoneNumber);
				//分配最佳手气红包
				ModelResult<ActivityOrderCouponRecordPO> autoDistribute = autoDistribute(dto);
				
				orderCouponRecord = autoDistribute.getData();
				couponAmount = optimumOrderCoupon.getCouponAmount();
				  //订单金额
				orderAmount = optimumOrderCoupon.getOrderAmount();
				couponName = optimumOrderCoupon.getCouponName();
			}else if(orderLinkPO.getManShiJianEr().intValue()==1){
				////2.3.2 生成满10减2红包
				UserStatus userStatus = dataReadDao.queryOne("UserStatusMapper.selectByPrimaryKey", userId);
				if(userStatus!=null){
					//0,正常用户 1，低频用户，2，僵尸用户，3,流失用户
					String status = userStatus.getStatus();
					
					if(StringUtils.equals(status, "0")){
						//概率10%
						manShiJianEr = ProbabilityCalculationUtil.calculation(10);
					}else if(StringUtils.equals(status, "1")){
						//概率45%
						manShiJianEr = ProbabilityCalculationUtil.calculation(45);
					}else if(StringUtils.equals(status, "2")){
						//概率27%
						manShiJianEr = ProbabilityCalculationUtil.calculation(27);
					}else if(StringUtils.equals(status, "3")){
						//概率18%
						manShiJianEr = ProbabilityCalculationUtil.calculation(18);
					}
					if(manShiJianEr){
						//可以给用户分配满10减2红包
						ActivityOrderCouponVO manshiJianErCoupon = getOrderCoupon("2",null);
						ActivityOrderCouponRecordPO dto = new ActivityOrderCouponRecordPO();
						dto.setMemberId(userId);
						dto.setCouponId(manshiJianErCoupon.getCouponId());
						dto.setLinkId(linkId);
						dto.setNickName(linkCreateDTO.getNickName());
						dto.setRecordIndex(receiveIndex);
						dto.setIcon(linkCreateDTO.getIcon());
						dto.setOpenid(linkCreateDTO.getCretorOpenid());
						dto.setPhoneNumber(phoneNumber);
						//分配最佳手气红包
						orderCouponRecord = autoDistribute(dto).getData();
						couponAmount = manshiJianErCoupon.getCouponAmount();
						//订单金额
						orderAmount = manshiJianErCoupon.getOrderAmount();
						couponName = manshiJianErCoupon.getCouponName();
					}
				}
			}
			if(!optimum&&!manShiJianEr){
				//2.3.3 没有最佳手气红包，也没有满10减2红包,则分配满8-1红包
				ActivityOrderCouponVO manBaJian1Coupon = getOrderCoupon("3",null);
				ActivityOrderCouponRecordPO dto = new ActivityOrderCouponRecordPO();
				dto.setMemberId(userId);
				dto.setCouponId(manBaJian1Coupon.getCouponId());
				dto.setLinkId(linkId);
				dto.setNickName(linkCreateDTO.getNickName());
				dto.setRecordIndex(receiveIndex);
				dto.setIcon(linkCreateDTO.getIcon());
				dto.setOpenid(linkCreateDTO.getCretorOpenid());
				dto.setPhoneNumber(phoneNumber);
				//分配最佳手气红包
				orderCouponRecord = autoDistribute(dto).getData();
				couponAmount = manBaJian1Coupon.getCouponAmount();
				  //订单金额
				orderAmount = manBaJian1Coupon.getOrderAmount();
				couponName = manBaJian1Coupon.getCouponName();
			}
			OrderLinkCouponRecordDTO linkCouponRecordDTO = new OrderLinkCouponRecordDTO();
			linkCouponRecordDTO.setRecordId(orderCouponRecord.getRecordId());
			linkCouponRecordDTO.setStatus(orderCouponRecord.getStatus());
			linkCouponRecordDTO.setCouponAmount(couponAmount);
			linkCouponRecordDTO.setOrderAmount(orderAmount);
			linkCouponRecordDTO.setValidaTime(orderCouponRecord.getValidatTime());
			linkCouponRecordDTO.setCouponRecordId(orderCouponRecord.getCouponRecordId());
			linkCouponRecordDTO.setCouponName(couponName);
			returnDate.setLinkCouponRecordDTO(linkCouponRecordDTO);
			methodReturn.setData(returnDate);
		}

		ModelResult<OrderLinkPageInitDTO> data4 = new ModelResultClient<OrderLinkPageInitDTO>().successFactory(returnDate);
		LOGGER.info("接口返回数据:{}",JsonUtils.beanToJson(data4));
		return data4;
	}
	
	private ModelResult<ActivityOrderCouponRecordPO> autoDistribute(ActivityOrderCouponRecordPO dto) {
		String userId = dto.getMemberId();
		String couponId =dto.getCouponId();
		String linkId = dto.getLinkId();
		String nickName = dto.getNickName();
		Integer recordIndex = dto.getRecordIndex();
		String openid = dto.getOpenid();
		String icon = dto.getIcon();
		String phoneNumber = dto.getPhoneNumber();
		
		String commonCouponRecordId = "";
		Date commonCouponValidaTime = null;
		{
			//如果用户已经注册，则分配真正的优惠券
			if(StringUtils.isNotEmpty(phoneNumber)){
				// 生成优惠券记录
				DistributeCouponDTO vo = new DistributeCouponDTO();
				vo.setCouponId(couponId);
				vo.setUserid(userId);
				vo.setNickname(nickName);
				
				ModelResult<CouponRecordPO> distributeOrderLinkCoupon = createCommonCoupon(vo);
				if(!distributeOrderLinkCoupon.isSuccess()){
					return new ModelResultClient<ActivityOrderCouponRecordPO>().failFactory(distributeOrderLinkCoupon.getCode(), distributeOrderLinkCoupon.getMsg());
				}
				CouponRecordPO data = distributeOrderLinkCoupon.getData();
				commonCouponRecordId = data.getRecordId();
				commonCouponValidaTime = data.getValidTime();
			}else{
				CouponPO avalibleCoupon =getCoupon(couponId);
				if (avalibleCoupon.getWhetherDay().intValue() == 1) {
					Integer validDay = avalibleCoupon.getValidDay();
					
			    	DateUtil dateUtil = new DateUtil();
			    	Date date = new Date();
			    	String formatDate = dateUtil.formatDate(dateUtil.addDate(date, validDay-1), "yyyy-MM-dd");
			    	formatDate=formatDate+" 23:59:59";
					commonCouponValidaTime = dateUtil.parseDate(formatDate, "yyyy-MM-dd HH:mm:ss");
				} else {
					commonCouponValidaTime =avalibleCoupon.getValidTime();
				}
			}
		}
		//插入活动优惠券记录
		ActivityOrderCouponRecordPO recordPO = new ActivityOrderCouponRecordPO();
		recordPO.setRecordId(UUID.randomUUID().toString().replace("-", ""));
		recordPO.setLinkId(linkId);
		recordPO.setCouponId(couponId);
		recordPO.setCouponRecordId(commonCouponRecordId);
		recordPO.setMemberId(userId);
	
		recordPO.setOpenid(openid);
		recordPO.setRecordIndex(recordIndex);
		recordPO.setCreateTime(new Date());
		recordPO.setNickName(nickName);
		recordPO.setIcon(icon);
		//如果用户未注册，默认优惠券未领取
		if(StringUtils.isEmpty(phoneNumber)){
			recordPO.setStatus(0);
		}else{
			recordPO.setStatus(1);
		}
		// 优惠券获得方式：1 普通分享获得；2 注册分享类型
		recordPO.setCouponType("1");
		recordPO.setValidatTime(commonCouponValidaTime);
		activityWriteDao.insertAndReturnAffectedCount("ActivityOrderCouponRecord.insert", recordPO);
		return new ModelResultClient<ActivityOrderCouponRecordPO>().successFactory(recordPO);
	}
	
	/**
	 * @Description:手动领取订单分享连接优惠券
	 * @date:2018年2月28日
	 * @author:fanmingcai
	 * @param orderLinkCreateDTO
	 * @return
	 */
	@Override
	public ModelResult<Boolean> receiveOrderLinkCoupon(@RequestBody ReceiveOrderLinkCouponDTO dto) {
		LOGGER.info("手动领取分享红包,dto:{}",JsonUtils.beanToJson(dto));
		//判断是否重复领取优惠券
		String userId = dto.getUserId();
		String orderCouponRecordId = dto.getOrderCouponRecordId();
		if(StringUtils.isEmpty(orderCouponRecordId)){
			return new ModelResultClient<Boolean>().failFactory("5000", "非法数据");
		}
		ActivityOrderCouponRecordPO orderCouponRecord = getOrderCouponRecord(orderCouponRecordId);
		if(!StringUtils.equals(userId, orderCouponRecord.getMemberId())){
			return new ModelResultClient<Boolean>().failFactory("5001", "非法请求");
		}
		if(orderCouponRecord.getStatus().intValue()==1){
			return new ModelResultClient<Boolean>().failFactory("5002", "重复领取优惠券");
		}
		String couponId = orderCouponRecord.getCouponId();
		String nickName = orderCouponRecord.getNickName();
		
		//1.生成普通优惠券数据
		DistributeCouponDTO vo = new DistributeCouponDTO();
		vo.setCouponId(couponId);
		vo.setUserid(userId);
		vo.setNickname(nickName);
		ModelResult<CouponRecordPO> distributeOrderLinkCoupon = createCommonCoupon(vo);
		CouponRecordPO data = distributeOrderLinkCoupon.getData();
		String commonCouponRecordId = data.getRecordId();
		Date validTime = data.getValidTime();
		
		//2.更新分享优惠券领取记录
		HashMap<String, Object> params0 = Maps.newHashMap();
		params0.put("validTime", validTime);
		params0.put("recordId", orderCouponRecordId);       
		params0.put("couponRecordId", commonCouponRecordId);//这个值获取不到   
		activityWriteDao.update("ActivityOrderCouponRecord.update", params0);
		//3.生成注册类型的优惠券
		String registerCouponId = dto.getRegisterCouponId();
		if(StringUtils.isNoneEmpty(registerCouponId)){
			Date commonCouponValidaTime = null;
			CouponPO coupon = getCoupon(registerCouponId);
			
			if (coupon.getWhetherDay().intValue() == 1) {
				Integer validDay = coupon.getValidDay();
		    	DateUtil dateUtil = new DateUtil();
		    	Date date = new Date();
		    	String formatDate = dateUtil.formatDate(dateUtil.addDate(date, validDay-1), "yyyy-MM-dd");
		    	formatDate=formatDate+" 23:59:59";
				commonCouponValidaTime = dateUtil.parseDate(formatDate, "yyyy-MM-dd HH:mm:ss");
			} else {
				commonCouponValidaTime =coupon.getValidTime();
			}
			
			//插入活动优惠券记录
			ActivityOrderCouponRecordPO recordPO = new ActivityOrderCouponRecordPO();
			recordPO.setRecordId(UUID.randomUUID().toString().replace("-", ""));
			recordPO.setLinkId(orderCouponRecord.getLinkId());
			recordPO.setCouponId(registerCouponId);
			recordPO.setCouponRecordId("");
			recordPO.setMemberId(userId);
			recordPO.setNickName(nickName);
			recordPO.setIcon(orderCouponRecord.getIcon());
			recordPO.setOpenid(orderCouponRecord.getOpenid());
			recordPO.setRecordIndex(0);
			recordPO.setCreateTime(new Date());
			//如果用户未注册，默认优惠券未领取
			recordPO.setStatus(1);
			// 优惠券获得方式：1 普通分享获得；2 注册分享类型
			recordPO.setCouponType("2");
			recordPO.setValidatTime(commonCouponValidaTime);
			activityWriteDao.insertAndReturnAffectedCount("ActivityOrderCouponRecord.insert", recordPO);
		}
		return new ModelResultClient<Boolean>().successFactory(true);
	}
	
	//查询订单链接
	private ActivityOrderLinkPO getOrderLink(String orderId,String userId,String openId){
		HashMap<String, Object> params0 = Maps.newHashMap();
		params0.put("orderId", orderId);                  
		ActivityOrderLinkPO orderLink = null;
		orderLink = activityReadDao.queryOne("ActivityOrderLinkMapper.getOne", params0);
//		if(orderLink==null){
//			//如果分享链接为空，则线程休眠三秒钟
//			try {
//				Thread.sleep(3);
//			} catch (InterruptedException e) {
//				e.printStackTrace();
//			}
//			orderLink = activityReadDao.queryOne("ActivityOrderLinkMapper.getOne", params0);
//		}
		if(orderLink==null){
			ActivityOrderLinkPO orderLinkPO = new ActivityOrderLinkPO();
			orderLinkPO.setLinkId(IDGeneratorUtil.nextId());
			orderLinkPO.setOrderId(orderId);
			orderLinkPO.setCreateTime(new Date());
			int queryInt = activityReadDao.queryInt("ActivityOrderLinkMapper.countIndex", null);
			//是否产生满10减2红包
			Integer manShiJianEr=0;
			if((queryInt+1)%10==0){
				manShiJianEr = 1;
				orderLinkPO.setManShiJianEr(1);
			}else{
				manShiJianEr=0;
				orderLinkPO.setManShiJianEr(0);
			}
			//计算最佳手气顺位（第6或者第7位）
			boolean calculation = ProbabilityCalculationUtil.calculation(70);
			orderLinkPO.setOptimumIndex(calculation?6:7);
			orderLinkPO.setCreatorId(userId);
			orderLinkPO.setCretorOpenid(openId);
			int affectedCount = activityReadDao.insertAndReturnAffectedCount("ActivityOrderLinkMapper.insert", orderLinkPO);
			if(affectedCount==0){
				orderLink = activityReadDao.queryOne("ActivityOrderLinkMapper.getOne", params0);
				return orderLink;
			}
			orderLink = new ActivityOrderLinkPO();
			orderLink.setLinkId(orderLinkPO.getLinkId());
			orderLink.setManShiJianEr(manShiJianEr);//是否产生满10减2红包:1产生 ;0不产生
			orderLink.setOrderId(orderId);//订单id',
			orderLink.setCreateTime(new Date());//分享链接生成时间'
			orderLink.setCreatorId(userId);//分享发起人id',
			orderLink.setCretorOpenid(openId);//分享发起人openid',
			orderLink.setOptimumIndex(orderLinkPO.getOptimumIndex());//最佳手气红包(满10减3)顺位值:6或7
		}
		return orderLink;
	}
	
	//查询链接分享记录
	private ActivityOrderCouponRecordPO getOrderCouponRecord(String recordId){
		HashMap<String, Object> params0 = Maps.newHashMap();
		params0.put("recordId", recordId);                  
		ActivityOrderCouponRecordPO record = activityReadDao.queryOne("ActivityOrderCouponRecord.getOne", params0);
		return record;
	}
	
	//查询分享优惠券；couponType:优惠券类型:1表示满10减3; 2表示满10减2;3表示满8减1
	private ActivityOrderCouponVO getOrderCoupon(String couponType,String couponId){
		HashMap<String, Object> params0 = Maps.newHashMap();
		params0.put("couponType", couponType);   
		params0.put("couponId", couponId);   
		ActivityOrderCouponVO orderLink = activityReadDao.queryOne("ActivityOrderCouponMapper.getOne", params0);
		return orderLink;
	}
	
	/**
	 * 
	 * @Description:给用户发分享红包优惠券
	 * @date:2018年2月1日
	 * @author:fanmingcai
	 * @param userBean
	 * @return
	 */
	private ModelResult<CouponRecordPO> createCommonCoupon(DistributeCouponDTO dto) {
		String couponId = dto.getCouponId();
		String userid = dto.getUserid();
		String nickname = dto.getNickname();
		CouponPO avalibleCoupon =getCoupon(couponId);
		
		LOGGER.info("优惠券{}给用户{}派发,先判断有效期,startTime:{},endTime:{}", couponId, userid,
				DateUtil.formatTime(avalibleCoupon.getStartTime()), DateUtil.formatTime(avalibleCoupon.getEndTime()));
		if(avalibleCoupon!=null){
			//普通优惠券
			CouponRecordPO couponRecordPO = new CouponRecordPO();
			couponRecordPO.setCouponId(avalibleCoupon.getCouponId().toString());
			couponRecordPO.setCouponSn(UUID.randomUUID().toString().replace("-", ""));
			couponRecordPO.setCouponPwd(null);
			couponRecordPO.setCouponTime(new Date());
			couponRecordPO.setUserId(userid);
			couponRecordPO.setUserName(nickname);
			couponRecordPO.setUserdTime(null);
			couponRecordPO.setOrderId(null);
			couponRecordPO.setCouponStatus("2");
			if (avalibleCoupon.getWhetherDay().intValue() == 1) {
				Integer validDay = avalibleCoupon.getValidDay();
		    	DateUtil dateUtil = new DateUtil();
		    	Date date = new Date();
		    	String formatDate = dateUtil.formatDate(dateUtil.addDate(date, validDay-1), "yyyy-MM-dd");
		    	formatDate=formatDate+" 23:59:59";
				Date parseDate = dateUtil.parseDate(formatDate, "yyyy-MM-dd HH:mm:ss");
				couponRecordPO.setValidTime(parseDate);
			} else {
				couponRecordPO.setValidTime(avalibleCoupon.getValidTime());
			}
			couponRecordPO.setCouponChannel("3");//分享红包获得优惠券
			Integer recordId = feng1WriteDao.insertAndSetupId("CouponRecordMapper.insertOne", couponRecordPO);
			couponRecordPO.setRecordId(couponRecordPO.getRecordId());
	        return new ModelResultClient<CouponRecordPO>().successFactory(couponRecordPO);
		}
		return new ModelResultClient<CouponRecordPO>().failFactory("4005","找不到可用的优惠券");
		
	}
	
	private CouponPO getCoupon(String couponId){
		HashMap<String, Object> params2 = new HashMap<String,Object>();
		params2.put("couponId", couponId);
		CouponPO avalibleCoupon = (CouponPO)feng1ReadDao.queryOne("CouponMapper.getOne", params2);
		return avalibleCoupon;
	}


}

