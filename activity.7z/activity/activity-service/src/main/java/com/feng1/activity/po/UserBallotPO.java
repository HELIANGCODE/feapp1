package com.feng1.activity.po;

import lombok.Data;

import java.io.Serializable;

@Data
public class UserBallotPO implements Serializable{
    private static final long serialVersionUID = 2317166370527478365L;

    // 签语表
    private String ballotId;//签语编号
    private String content;//签语内容
    private String dataFlag;//数据状态(1:正常、2:删除)

}
