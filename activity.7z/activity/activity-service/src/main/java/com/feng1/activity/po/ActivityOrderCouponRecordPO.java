package com.feng1.activity.po;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;

@Data
public class ActivityOrderCouponRecordPO  implements Serializable{
	private static final long serialVersionUID = 1L;
	//订单手气红包领用记录
	  String recordId;//记录主键',
	  String linkId;//分享链接id',
	  String couponId;//优惠券id',
	  String couponRecordId;//优惠券记录id',
	  String memberId;//领用人id',
	  String openid;//领用人openid',
	  Integer recordIndex;//链接红包领取顺序，用于计算是否获得手气红包'
	  Date createTime;
	  
	  String nickName;
	  String icon;
	  Integer status;//领取状态:0 未领取；1已领取
	  Date validatTime;//有效期
	  String phoneNumber;
	  
	  // 优惠券获得方式：1 普通分享获得；2 注册分享类型
	  String couponType;
	  
}
