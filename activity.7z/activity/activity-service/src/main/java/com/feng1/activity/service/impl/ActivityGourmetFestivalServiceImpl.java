package com.feng1.activity.service.impl;

import com.feng1.activity.dto.GourmetFestivalDTO;
import com.feng1.activity.po.GourmetFestivalPO;
import com.feng1.activity.service.IActivityGourmetFestivalService;
import com.feng1.framework.common.dao.GenericDao;
import com.feng1.framework.common.domain.result.ModelResult;
import com.feng1.framework.common.domain.result.ModelResultClient;
import com.feng1.framework.common.util.IDGeneratorUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class ActivityGourmetFestivalServiceImpl implements IActivityGourmetFestivalService {

    private static final Logger LOGGER = LoggerFactory.getLogger(ActivityGourmetFestivalServiceImpl.class);

    @Autowired
    @Qualifier("activityReadDao")
    private GenericDao activityReadDao;

    @Autowired
    @Qualifier("activityWriteDao")
    private GenericDao activityWriteDao;

    @Override
    public ModelResult<GourmetFestivalDTO> getTestResult(@RequestParam("userId") String userId) {
        GourmetFestivalDTO gourmetFestivalDTO = activityReadDao.queryOne("ActivityGourmetFestivalMapper.getByUserId", userId);
        LOGGER.debug("用户{}测试结果文案:{}", userId, gourmetFestivalDTO);
        return new ModelResultClient<GourmetFestivalDTO>().successFactory(gourmetFestivalDTO);
    }


    @Override
    public ModelResult updateTestResult(@RequestParam("userId") String userId) {
        GourmetFestivalPO gourmetFestivalPO = new GourmetFestivalPO();
        gourmetFestivalPO.setUserId(userId);
        gourmetFestivalPO.setId(IDGeneratorUtil.nextId());
        gourmetFestivalPO.setIsReceived("1");
        activityWriteDao.insertAndReturnAffectedCount("ActivityGourmetFestivalMapper.insert", gourmetFestivalPO);
        LOGGER.info("更新用户{}的状态为已领取517吃货节优惠券!", userId);
        return new ModelResultClient<>().successFactory();
    }
}
