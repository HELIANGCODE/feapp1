package com.feng1;

import org.springframework.boot.SpringApplication;

public class ActivityServiceApplication extends ServiceApplication{

    public static void main(String[] args) {
        System.out.println(ActivityServiceApplication.class+"starting app!");
        SpringApplication.run(ActivityServiceApplication.class, args);
    }
}
