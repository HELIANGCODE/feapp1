package com.feng1.share;

public class TestVolatile {
    public static void main(String[] args) {

    }
    class Bank {
        private volatile int account = 100;
        public int getAccount(){
            return account;
        }
        /**
         * 同步代码块实现
         */
        public synchronized void save(int money){
           account += money;
        }

        public void save1(int money){
            synchronized (this){
                account += money;
            }
        }
    }
    class NewThread implements Runnable {
        private Bank bank;
        public NewThread(Bank bank){
            this.bank = bank;
        }

        @Override public void run() {
            for(int i = 0;i<10;i++){
                bank.save(10);
                System.out.println(i + "账户余额为：" +bank.getAccount());
            }
        }
    }
    /**
     * 建立线程，调用内部类
     */

}
