package com.feng1.share;

import java.util.concurrent.CyclicBarrier;

public class TestBarrier {
    public static void main(String[] args) {
        //创建障碍器，并设置MainTask为所有定数量的线程都达到障碍点时候所要执行的任务(Runnable)
        CyclicBarrier cyclicBarrier = new CyclicBarrier(7,new MainTask());
        new SubTask("A", cyclicBarrier).start();
        new SubTask("B", cyclicBarrier).start();
        new SubTask("C", cyclicBarrier).start();
        new SubTask("D", cyclicBarrier).start();
        new SubTask("E", cyclicBarrier).start();
        new SubTask("F", cyclicBarrier).start();
        new SubTask("G", cyclicBarrier).start();
    }
    //主任吴
    static class MainTask implements Runnable {

        @Override public void run() {
            System.out.println(">>>>主任务执行了！<<<<");
        }
    }
    //子任务
    static class SubTask extends Thread{
        private String name;
        private CyclicBarrier cyclicBarrier;
        SubTask(String name, CyclicBarrier cb){
           this.name = name;
           this.cyclicBarrier = cb;
        }
        public void run(){
            System.out.println("[子任务"+name+"]开始执行了！");
            for(int i = 0;i<999999;i++){
                System.out.println("[子任务" + name +"]开始执行完成了，并通知障碍器已经完成！");
                try {
                    //通知障碍器已经完成
                    cyclicBarrier.await();
                }catch(Exception e){
                    e.printStackTrace();
                }
            }
        }
    }
}
