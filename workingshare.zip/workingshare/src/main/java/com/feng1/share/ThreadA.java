package com.feng1.share;

public class ThreadA {
    public static void main(String[] args) {
        ThreadB threadB = new ThreadB();
        threadB.start();
        synchronized (threadB){
            try {
                System.out.println("等待对象b完成计算......");
                threadB.wait();
            } catch (InterruptedException e){
                e.printStackTrace();
            }
            System.out.println("b对象计算的总和是：" + threadB.total);
        }
    }

    /**
     * 计算1+2+3+...+100的和
     */
     static class ThreadB extends Thread {
        int total;
        public void run(){
            synchronized (this){
                for(int i=0;i<101;i++){
                    total+=i;
                }
                //（完成计算了）唤醒在此对象监视器上等待的单个线程，在本例中线程A被唤醒
                notify();
            }
        }
    }
}


