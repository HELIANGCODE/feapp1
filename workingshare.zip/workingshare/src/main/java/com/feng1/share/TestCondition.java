package com.feng1.share;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class TestCondition {
    public static void main(String[] args) {
        //创建并发访问的账户
        MyCount1 myCount=new MyCount1("6215580000000000000",10000);
        ExecutorService pool = Executors.newFixedThreadPool(2);
        Thread t1 = new SaveThread("张三", myCount, 2000);
        Thread t2 = new SaveThread("李四", myCount, 3600);
        Thread t3 = new DrawThread("王五", myCount, 2700);
        Thread t4 = new SaveThread("老张", myCount, 600);
        Thread t5 = new DrawThread("老牛", myCount, 1300);
        Thread t6 = new DrawThread("胖子", myCount, 800);
        pool.execute(t1);
        pool.execute(t2);
        pool.execute(t3);
        pool.execute(t4);
        pool.execute(t5);
        pool.execute(t6);
        pool.shutdown();
    }
    //存款线程类
    static class SaveThread extends Thread {
        private String name;
        private MyCount1 myCount1;
        private int x;

        SaveThread(String name, MyCount1 myCount, int x){
            this.name = name;
            this.myCount1 = myCount;
            this.x = x;
        }

         @Override public void run(){
            myCount1.saving(x,name);
         }
    }
    //取款线程类
    static class DrawThread extends Thread {
        private String name;
        private MyCount1 myCount1;
        private int x;

        DrawThread(String name, MyCount1 myCount, int x){
            this.name = name;
            this.myCount1 = myCount;
            this.x = x;
        }

        @Override public void run(){
            myCount1.drawing(x,name);
        }
    }

    //普通银行账户
    static class MyCount1{
        private String oid;
        private int cash;
        //账户锁
        private Lock lock = new ReentrantLock();
        //存款条件
        private Condition _save = lock.newCondition();
        //取款条件
        private Condition _draw = lock.newCondition();
        MyCount1(String oid, int cash){
           this.oid = oid;
           this.cash = cash;
        }
        /**
         * 存款
         */
        public void saving(int x,String name){
            lock.lock();
            if(x > 0){
                cash += x;
                System.out.println(name + "存款" + x + "，当前余额为" + cash);
            }
            _draw.signalAll();
            lock.unlock();
        }
        /**
         * 取款
         */
        public void drawing(int x,String name){
            lock.lock();
            try{
                if(cash - x < 0){
                    _draw.await();//等待
                }else{
                    cash -= x;
                    System.out.println(name + "取款" + x + "，当前余额为" + cash);
                }
                _save.signalAll();
            }catch(Exception e){
                e.printStackTrace();
            }finally {
                lock.unlock();
            }
        }
    }
}
